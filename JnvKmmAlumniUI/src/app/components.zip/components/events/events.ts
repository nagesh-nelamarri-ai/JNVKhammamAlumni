import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { EventCard } from '../event-card/event-card';
import { InputTextModule } from 'primeng/inputtext';
import { Dialog } from 'primeng/dialog';
import { FormsModule } from '@angular/forms';

interface Event {
  title: string;
  subtitle: string;
  image: string;
  description: string;
}

@Component({
  selector: 'app-events',
  imports: [CommonModule, CardModule, ButtonModule, Dialog,
    InputTextModule,
    FormsModule],
  providers: [DialogService],
  templateUrl: './events.html',
  styleUrl: './events.css',
  standalone: true

})
export class Events {
  ref: DynamicDialogRef | undefined;
  constructor(public dialogService: DialogService) { }
  addEvent1() {
    this.ref = this.dialogService.open(EventCard, {
      header: 'Add Event',
      width: '50%',
      baseZIndex: 10000,
      modal: true,
      closable: true
    });
  }

  visible: boolean = false;

  showEventDialog() {
    this.visible = true;
  }


  events: Event[] = [];

  newEvent: Event = {
    title: '',
    subtitle: '',
    image: '',
    description: ''
  };

  showForm = false;

  addEvent() {
    if (this.newEvent.title && this.newEvent.image) {
      this.events.push({ ...this.newEvent });
      this.newEvent = { title: '', subtitle: '', image: '', description: '' };
      this.showForm = false;
      this.visible = false;
    }
  }

}
