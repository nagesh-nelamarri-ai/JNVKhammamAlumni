import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CardModule } from 'primeng/card';
import { ImageModule } from 'primeng/image';

@Component({
  selector: 'app-gallery',
  imports: [
    CommonModule,
    ImageModule,
    CardModule
],
  templateUrl: './gallery.html',
  styleUrl: './gallery.css',
  standalone: true

})
export class Gallery {
 events = [
    {
      image: 'https://primefaces.org/cdn/primeng/images/galleria/galleria10.jpg',
      header: 'Tech Conference 2025',
      date: new Date('2025-11-20'),
      description: 'Join us for a day of insightful talks and networking with industry leaders.',
      link: 'https://example.com/tech-conference'
    },
    {
      image: 'https://primefaces.org/cdn/primeng/images/galleria/galleria11.jpg',
      header: 'Angular Workshop',
      date: new Date('2025-12-05'),
      description: 'Hands-on workshop to master Angular and PrimeNG components.',
      link: 'https://example.com/angular-workshop'
    }
  ];
}
