import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { MenubarModule } from 'primeng/menubar';
import { Header } from '../header/header';
import { Footer } from '../footer/footer';
import { RouterOutlet } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { DialogService, DynamicDialogRef } from 'primeng/dynamicdialog';
import { Registration } from '../registration/registration';

@Component({
  selector: 'app-home',
  imports: [RouterOutlet, ButtonModule, CommonModule, MenubarModule, Header, Footer],
  providers: [DialogService],
  templateUrl: './home.html',
  styleUrl: './home.css',
  standalone: true
})
export class Home implements OnInit {

  items: MenuItem[] | undefined;
  ref: DynamicDialogRef | undefined;
  constructor(public dialogService: DialogService) { }

  ngOnInit() {
    this.items = [
      {
        label: 'Home',
        icon: 'pi pi-home',
        routerLink: ['homecontent']
      },
      {
        label: 'Members',
        icon: 'pi pi-user',
        routerLink: ['members']
      },
      {
        label: 'Events',
        icon: 'pi pi-calendar',
        routerLink: ['events'],
        // items: [
        //   {
        //     label: 'Alumni',
        //     icon: 'pi pi-bolt'
        //   },
        //   {
        //     label: 'Sports',
        //     icon: 'pi pi-server'
        //   },
        //   {
        //     label: 'Career',
        //     icon: 'pi pi-pencil'
        //   },
        // ]
      },
      {
        label: 'Gallery',
        icon: 'pi pi-image',
        routerLink: ['gallery']
      },
      {
        label: 'Contact Us',
        icon: 'pi pi-address-book',
        routerLink: ['contactus']
      },
    ]
  }

  OpenRegisterForm() {
    this.ref = this.dialogService.open(Registration, {
      header: 'Registration Form',
      width: '50%',
      baseZIndex: 10000,
      modal: true,
      closable: true
    });
  }


}
