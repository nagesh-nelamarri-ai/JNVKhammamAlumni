import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, ReactiveFormsModule, FormGroup } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { InputTextModule } from 'primeng/inputtext';
import { FileUploadModule } from 'primeng/fileupload';
import { ButtonModule } from 'primeng/button';
import { Registraion } from '../../service/registraion';
import { DynamicDialogRef } from 'primeng/dynamicdialog';
import { Dialog } from "primeng/dialog";
// import { InputTextareaModule } from 'primeng/inputtextarea';

@Component({
  selector: 'app-registration',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    InputTextModule,
    FileUploadModule,
    ButtonModule
],
  templateUrl: './registration.html',
  styleUrl: './registration.css',
  standalone: true,
  providers: [DynamicDialogRef]
})
export class Registration implements OnInit{
  public form: FormGroup = new FormGroup({}) ;
  isVisible: boolean = true;
  constructor(public fb: FormBuilder,private registrationService: Registraion,public ref: DynamicDialogRef) {}

  ngOnInit() {
  this.form = this.fb.group({
    name: ['', Validators.required],
    surname: ['', Validators.required],
    mobile: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
    email: ['', [Validators.required, Validators.email]],
    yearFrom: ['', [Validators.required, Validators.pattern(/^\d+$/)]],
    yearTo: ['', [Validators.required, Validators.pattern(/^\d+$/)]],
    batch: ['', Validators.required],
    profession: ['', Validators.required],
    profilePhoto: [null, Validators.required],
    comments: ['']
  });

  }
  onSubmit() {
    console.log('Form Submitted', this.form.value);
    this.registrationService.register(this.form.value).subscribe({
      next: () => {
        this.ref.close();
        this.isVisible = false; 
        alert('Registered successfully');
      },
      error: err => console.error('Error:', err)
    });
    if (this.form.valid) {
      console.log('Form Submitted', this.form.value);
      this.registrationService.register(this.form.value).subscribe({
        next: () => alert('Registered successfully'),
        error: err => console.error('Error:', err)
      });
    } else {
      this.form.markAllAsTouched();
    }
  }


  onFileSelect(event: any) {
    const file = event.files[0];
    const allowedTypes = ['image/jpeg', 'image/jpg', 'application/pdf'];
    if (file && allowedTypes.includes(file.type)) {
      this.form.patchValue({ profilePhoto: file });
    } else {
      this.form.patchValue({ profilePhoto: null });
      alert('Invalid file type. Only JPEG, JPG, and PDF are allowed.');
    }
  }

  getRegistrations() {
  this.registrationService.getAll().subscribe(data => {
    // this.registrations = data;
  });

  
}

}
