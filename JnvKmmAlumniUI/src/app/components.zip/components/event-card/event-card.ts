import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { CardModule } from 'primeng/card';
import { InputTextModule } from 'primeng/inputtext';


interface Event {
  title: string;
  subtitle: string;
  image: string;
  description: string;
}

@Component({
  selector: 'app-event-card',
  imports: [
    CommonModule,
    CardModule,
    ButtonModule,
    InputTextModule,
    FormsModule,
  ],
  templateUrl: './event-card.html',
  styleUrl: './event-card.css',
  standalone: true
})
export class EventCard {

  
events: Event[] = [];

  newEvent: Event = {
    title: '',
    subtitle: '',
    image: '',
    description: ''
  };

  showForm = false;

  addEvent() {
    if (this.newEvent.title && this.newEvent.image) {
      this.events.push({ ...this.newEvent });
      this.newEvent = { title: '', subtitle: '', image: '', description: '' };
      this.showForm = false;
    }
  }


}
