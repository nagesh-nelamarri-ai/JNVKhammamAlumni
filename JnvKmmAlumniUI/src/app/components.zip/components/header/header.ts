import { Component } from '@angular/core';
import { ImageModule } from 'primeng/image';

@Component({
  selector: 'app-header',
  imports: [ImageModule ],
  templateUrl: './header.html',
  styleUrl: './header.css',
  standalone: true

})
export class Header {

}