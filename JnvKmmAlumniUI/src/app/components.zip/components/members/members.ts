import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { CardModule } from 'primeng/card';

@Component({
  selector: 'app-members',
  imports: [CommonModule, CardModule],
  templateUrl: './members.html',
  styleUrl: './members.css',
  standalone: true

})
export class Members implements OnInit {

ngOnInit(): void {

}
 members = [
    {
      name: 'John Doe',
      photo: 'https://primefaces.org/cdn/primeng/images/galleria/galleria15.jpg',
      description: 'Frontend Developer with 5 years of experience.'
    },
    {
      name: 'Jane Smith',
      photo: 'https://primefaces.org/cdn/primeng/images/galleria/galleria13.jpg',
      description: 'UX Designer passionate about user-centered design.'
    }
  ];
}
