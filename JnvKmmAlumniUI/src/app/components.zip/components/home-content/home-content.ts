import { CommonModule } from '@angular/common';
import { Component, model, OnInit } from '@angular/core';
import { CardModule } from 'primeng/card';
import { GalleriaModule } from 'primeng/galleria';
import { Photoservice } from '../../service/photoservice';
import { ImageItem } from '../../models/imageitem';

@Component({
  selector: 'app-home-content',
  imports: [CommonModule, GalleriaModule, CardModule],
  providers: [Photoservice],
  templateUrl: './home-content.html',
  styleUrl: './home-content.css',
  standalone: true
})
export class HomeContent implements OnInit {

  // images = model<ImageItem[]>([]);
  images: ImageItem[] = [];

  responsiveOptions: any[] = [
    {
      breakpoint: '1300px',
      numVisible: 4
    },
    {
      breakpoint: '575px',
      numVisible: 1
    }
  ];
  constructor(private photoService: Photoservice) { }

  ngOnInit() {
    this.images = [];

    this.photoService.getImages().then((images) => {
      this.images = images;
      console.log('images', this.images)
    });

  }


  members = [
    {
      name: 'John Doe',
      photo: 'https://primefaces.org/cdn/primeng/images/galleria/galleria15.jpg',
      description: 'Frontend Developer with 5 years of experience.'
    },
    {
      name: 'Jane Smith',
      photo: 'https://primefaces.org/cdn/primeng/images/galleria/galleria13.jpg',
      description: 'UX Designer passionate about user-centered design.'
    }
  ];


}
